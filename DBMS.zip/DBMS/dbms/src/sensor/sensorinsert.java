package sensor;

import javax.swing.*;

import devicetype.devicetypedelete;
import devicetype.devicetypeinsert;
import devicetype.devicetypeview;
import domain.domaindelete;
import domain.domaininsert;
import domain.domainview;
import usedfor.usedfordelete;
import usedfor.usedforinsert;
import usedfor.usedforview;
import usedin.usedindelete;
import usedin.usedininsert;
import usedin.usedinview;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class sensorinsert extends JFrame {
	          private JPanel panel;
	          private JLabel label5;
	          private JTextField t1;
	          private JLabel label1;
	          private JTextField t2;
	          private JLabel label2;
	          private JTextField t3;
	          private JTextField t4;
	          private JLabel label3;
	          private JLabel label4;
	          private JTextField t5;
	          private JButton insert;
        	  private JMenuItem insert1;
        	  private JMenuItem delete1;
        	  private JMenuItem view1;
        	  private JMenuItem insert2;
        	  private JMenuItem delete2;
        	  private JMenuItem view2;
        	  private JMenuItem insert3;
        	  private JMenuItem delete3;
        	  private JMenuItem view3;
        	  private JMenuItem insert4;
        	  private JMenuItem delete4;
        	  private JMenuItem view4;
        	  private JMenuItem insert5;
        	  private JMenuItem delete5;
        	  private JMenuItem view5;
    
        	 
        	  
        	  private JFrame frame;
        	  private JMenuBar menubar;
        	  private JMenu sensor;
        	  
        	  private JMenu devicetype;
        	  private JMenu domain;
        	  
        	  private JMenu usedin;
        	  private JMenu usedfor;
	          public sensorinsert()
	          {
	        	  panel=new JPanel(new FlowLayout());
	        	  label2=new JLabel("type");
	        	  label1=new JLabel("energy");
	        	  label3=new JLabel("lifetime");
	        	  label4=new JLabel("cost");
	        	  label5=new JLabel("sensor_id");
	        	  insert=new JButton("insert");
	        	  t1=new JTextField(20);
	        	  t2=new JTextField(20);
	        	  t3=new JTextField(20);
	        	  t4=new JTextField(20);
	        	  t5=new JTextField(20);
	        	
	        	    sensor=new JMenu("sensor");
	           	    
	           	    devicetype=new JMenu("devicetype");
	             	domain =new JMenu("domain");
	           
	             	usedin =new JMenu("usedin");
	             	usedfor =new JMenu("usedfor");
	             	 insert1=new JMenuItem("insert");
		           	   delete1=new JMenuItem("delete");
		           	   view1=new JMenuItem("view");
		           	   insert2=new JMenuItem("insert");
		           	   delete2=new JMenuItem("delete");
		           	   view2=new JMenuItem("view");
		           	 insert3=new JMenuItem("insert");
		           	   delete3=new JMenuItem("delete");
		           	   view3=new JMenuItem("view");
		           	 insert4=new JMenuItem("insert");
		           	   delete4=new JMenuItem("delete");
		           	   view4=new JMenuItem("view");
		           	 insert5=new JMenuItem("insert");
		           	   delete5=new JMenuItem("delete");
		           	   view5=new JMenuItem("view");
		           	 
	           	
	           	frame=new JFrame("Menu");
	           	menubar=new JMenuBar();
	            this.add(panel);
	        	 
	        	  this.setVisible(true);
	        	  this.setDefaultCloseOperation(3);
	        	  this.setSize(1000,300);
	        	 
         	   this.setJMenuBar(menubar);
         	  
         	  
	        	  panel.add(label1);
	        	  panel.add(t1);
	        	  panel.add(label2);
	        	  panel.add(t2);
	        	  panel.add(label3);
	        	  panel.add(t3);
	        	  panel.add(label4);
	        	  panel.add(t4);
	        	  panel.add(label5);
	        	  panel.add(t5);
	        	  panel.add(insert);
	        	  
	        	 
           	   
           	  
  
           	  
           	  menubar.add(sensor);

           	  sensor.add(insert1);
           	  sensor.add(delete1);
           	  sensor.add(view1);
           	  
           	  menubar.add(devicetype);
           	  devicetype.add(insert3);
              devicetype.add(delete3);
               devicetype.add(view3);
               menubar.add(domain);
            	  domain.add(insert4);
               domain.add(delete4);
                domain.add(view4);
               
                 menubar.add(usedin);
              	  usedin.add(insert2);
                 usedin.add(delete2);
                  usedin.add(view2);
                  menubar.add(usedfor);
               	  usedfor.add(insert5);
                  usedfor.add(delete5);
                   usedfor.add(view5);
	     
	          insert1.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						new sensorinsert();
						dispose();
						
					}
               }
               );
               view1.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					
					       new sensorview();
					       dispose();
					}
				}
               
              
               
             );
               delete1.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
				
					       new sensordelete();
					       dispose();
					}
				}
                
               
                
              );
             
               insert3.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
					       new devicetypeinsert();
					       dispose();
					}
				}
                
               
                
              );
               delete3.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					
					       new devicetypedelete();
					       dispose();
					}
				}
                
               
                
              );
               view3.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
			
					       new devicetypeview();
					       dispose();
					}
				}
               );
               insert4.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					
					       new domaininsert();
					       dispose();
					}
				}
               
              
               
             );
              delete4.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
					       new domaindelete();
					       dispose();
					}
				}
               
              
               
             );
              view4.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					
						
					       new domainview();
					       dispose();
					}
				}
              );
             
             insert4.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					
					       new usedininsert();
					       dispose();
					}
				}
             
            
             
           );
            delete4.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
					       new usedindelete();
					       dispose();
					}
				}
             
            
             
           );
            view4.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
					
						
					       new usedinview();
					       dispose();
					}
				}
            );
            insert5.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				
				       new usedforinsert();
				       dispose();
				}
			}
            
           
            
          );
           delete5.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
				       new usedfordelete();
				       dispose();
				}
			}
            
           
            
          );
           view5.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				
					
				       new usedforview();
				       dispose();
				}
           }
           );
           
           insert.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if(t1.getText().compareTo("")==0 || t2.getText().compareTo("")==0 || t3.getText().compareTo("")==0 || t4.getText().compareTo("")==0 || t5.getText().compareTo("")==0)
					{
						JOptionPane.showMessageDialog(null, "Enter All Fields");
					}
					else
					{
						try{  
							 
							Class.forName("oracle.jdbc.driver.OracleDriver");   
							  
							Connection con=DriverManager.getConnection(  
							"jdbc:oracle:thin:@localhost:1521:xe","swaroop","vasavi");  
							  
							Statement stmt=con.createStatement(); 
							
							int x=stmt.executeUpdate("insert into sensor values("+t5.getText()+","+t4.getText()+","+t3.getText()+",'"+t1.getText()+"','"+t2.getText()+"')"); 
							System.out.println("Insert rows="+x);
							con.commit();
							t1.setText("");
							t2.setText("");
							t3.setText("");
							t4.setText("");
							t5.setText("");
							con.close();   
							}catch(Exception ex){ System.out.println(ex);}  
					}
				}
			});
         }
         public static void main(String args[])
         {
       	  new sensorinsert();
       	  
         }
         
}

           
           
           
           
           
           
           
           
           
           
           